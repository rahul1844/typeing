import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Timer, Zap, Target, RefreshCcw, Keyboard, Trophy, Settings, BarChart3, Info, Volume2, VolumeX, Sun, Moon, Phone, Mail, User, ArrowRight, Wind, Pause, Play } from 'lucide-react';
import confetti from 'canvas-confetti';
import { generateTypingText } from './services/geminiService';
import { GameState, Word, TypingStats, UserProfile, UserStats, PracticeMode } from './types';
import { cn } from './lib/utils';
import { VirtualKeyboard } from './components/VirtualKeyboard';

const TIME_LIMITS = [15, 30, 60, 120, 180, 300, 0]; // 0 for Zen Mode

const DEFAULT_USER: UserProfile = {
  username: "Student Archer",
  avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${Math.random()}`,
  joinedAt: Date.now(),
  stats: {
    totalTests: 0,
    averageWpm: 0,
    bestWpm: 0,
    totalTime: 0,
    averageAccuracy: 0
  },
  settings: {
    theme: 'dark',
    soundEnabled: true,
    keyVolume: 0.2,
    ambientVolume: 0.15,
    difficulty: 'medium'
  },
  isRegistered: false
};

const getRank = (wpm: number) => {
  if (wpm >= 120) return { name: "Legendary", color: "text-amber-500" };
  if (wpm >= 100) return { name: "Grandmaster", color: "text-purple-500" };
  if (wpm >= 80) return { name: "Master", color: "text-red-500" };
  if (wpm >= 60) return { name: "Pro", color: "text-blue-500" };
  if (wpm >= 40) return { name: "Intermediate", color: "text-emerald-500" };
  return { name: "Novice", color: "text-zinc-500" };
};

const TOPICS = [
  { id: "general", label: "General", icon: "🌍" },
  { id: "coding", label: "Coding", icon: "💻" },
  { id: "space", label: "Space", icon: "🚀" },
  { id: "science", label: "Science", icon: "🧪" },
  { id: "literature", label: "Literature", icon: "📚" },
  { id: "history", label: "History", icon: "🏛️" },
  { id: "nature", label: "Nature", icon: "🌿" },
  { id: "tech", label: "Technology", icon: "🤖" },
  { id: "sports", label: "Sports", icon: "⚽" },
  { id: "mythology", label: "Mythology", icon: "🔱" },
  { id: "art-history", label: "Art History", icon: "🎨" },
  { id: "pop-culture", label: "Pop Culture", icon: "🍿" }
];

export default function App() {
  const [gameState, setGameState] = useState<GameState>('idle');
  const [text, setText] = useState<string>("");
  const [words, setWords] = useState<Word[]>([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [inputValue, setInputValue] = useState("");
  const [timeLeft, setTimeLeft] = useState(30);
  const [selectedTime, setSelectedTime] = useState(30);
  const [stats, setStats] = useState<TypingStats | null>(null);
  const [history, setHistory] = useState<TypingStats[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [topic, setTopic] = useState("general");
  const [difficulty, setDifficulty] = useState("medium");
  const [mode, setMode] = useState("paragraph");
  const [practiceMode, setPracticeMode] = useState<PracticeMode>("timed");
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [liveAccuracy, setLiveAccuracy] = useState(100);
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_USER);
  const [showProfile, setShowProfile] = useState(false);
  const [showTips, setShowTips] = useState(false);
  const [showVolumeSettings, setShowVolumeSettings] = useState(false);
  const [lastKeyPressed, setLastKeyPressed] = useState("");
  const [regForm, setRegForm] = useState({ name: '', phone: '', email: '' });
  const [regError, setRegError] = useState("");
  const [isMistake, setIsMistake] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const pauseStartTimeRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const errorAudioRef = useRef<HTMLAudioElement | null>(null);
  const zenAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Mechanical keyboard click sound
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3');
    audioRef.current.volume = userProfile.settings?.keyVolume ?? 0.2;

    // Error sound
    errorAudioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3');
    errorAudioRef.current.volume = Math.min((userProfile.settings?.keyVolume ?? 0.2) * 1.5, 1.0);

    // Zen mode ambient sound (Rain/Soft Ambient)
    zenAudioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2432/2432-preview.mp3');
    zenAudioRef.current.loop = true;
    zenAudioRef.current.volume = 0.15;

    return () => {
      if (zenAudioRef.current) {
        zenAudioRef.current.pause();
        zenAudioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = userProfile.settings?.keyVolume ?? 0.2;
    }
    if (errorAudioRef.current) {
      errorAudioRef.current.volume = Math.min((userProfile.settings?.keyVolume ?? 0.2) * 1.5, 1.0);
    }
    if (zenAudioRef.current) {
      zenAudioRef.current.volume = userProfile.settings?.ambientVolume ?? 0.15;
    }
  }, [userProfile.settings?.keyVolume, userProfile.settings?.ambientVolume]);

  useEffect(() => {
    if (zenAudioRef.current) {
      const shouldPlay = gameState === 'playing' && selectedTime === 0 && userProfile.settings?.soundEnabled;
      
      if (shouldPlay) {
        zenAudioRef.current.play().catch(() => {});
      } else {
        zenAudioRef.current.pause();
        zenAudioRef.current.currentTime = 0;
      }
    }
  }, [gameState, selectedTime, userProfile.settings?.soundEnabled]);

  const playKeySound = () => {
    if (userProfile.settings?.soundEnabled && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
  };

  const playErrorSound = () => {
    if (userProfile.settings?.soundEnabled && errorAudioRef.current) {
      errorAudioRef.current.currentTime = 0;
      errorAudioRef.current.play().catch(() => {});
    }
  };

  const initGame = useCallback(async (newTopic?: string, newDifficulty?: string, newMode?: string) => {
    setIsLoading(true);
    try {
      const selectedTopic = newTopic || topic;
      const selectedDiff = newDifficulty || difficulty;
      const selectedMode = newMode || mode;
      
      const rawText = await generateTypingText(selectedTopic, selectedDiff, selectedMode);
      const wordList = rawText.split(' ').filter(w => w.length > 0).map(w => ({ text: w, status: 'pending' as const }));
      setText(rawText);
      setWords(wordList);
      setCurrentWordIndex(0);
      setInputValue("");
      setTimeLeft(selectedTime === 0 ? 0 : selectedTime);
      setGameState('idle');
      setStats(null);
      setStreak(0);
      setMaxStreak(0);
      setLiveAccuracy(100);
      startTimeRef.current = null;
      pauseStartTimeRef.current = null;
      if (timerRef.current) clearInterval(timerRef.current);
    } catch (error) {
      console.error("Failed to initialize game:", error);
    } finally {
      setIsLoading(false);
    }
  }, [topic, difficulty, mode, selectedTime]);

  useEffect(() => {
    initGame();
    try {
      const savedHistory = localStorage.getItem('typemaster_history');
      if (savedHistory) setHistory(JSON.parse(savedHistory));
      
      const savedProfile = localStorage.getItem('typemaster_profile');
      if (savedProfile) {
        const parsed = JSON.parse(savedProfile);
        // Merge with DEFAULT_USER to ensure all fields (like settings) exist
        const mergedProfile = {
          ...DEFAULT_USER,
          ...parsed,
          stats: { ...DEFAULT_USER.stats, ...parsed.stats },
          settings: { ...DEFAULT_USER.settings, ...parsed.settings }
        };
        setUserProfile(mergedProfile);
        setDifficulty(mergedProfile.settings.difficulty || 'medium');
        if (mergedProfile.settings.theme === 'light') {
          document.documentElement.classList.remove('dark');
        } else {
          document.documentElement.classList.add('dark');
        }
      }
    } catch (error) {
      console.error("Error loading saved data:", error);
    }
  }, []);

  const toggleTheme = () => {
    const currentTheme = userProfile.settings?.theme || 'dark';
    const newTheme: 'light' | 'dark' = currentTheme === 'dark' ? 'light' : 'dark';
    const newProfile: UserProfile = {
      ...userProfile,
      settings: { ...userProfile.settings, theme: newTheme }
    };
    setUserProfile(newProfile);
    localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
    
    if (newTheme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  };

  const toggleSound = () => {
    const newProfile: UserProfile = {
      ...userProfile,
      settings: { 
        ...userProfile.settings, 
        soundEnabled: !userProfile.settings?.soundEnabled 
      }
    };
    setUserProfile(newProfile);
    try {
      localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
    } catch (e) {
      console.error("Failed to save profile:", e);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regForm.phone) {
      setRegError("Phone number is required for registration.");
      return;
    }
    
    const newProfile: UserProfile = {
      ...userProfile,
      username: regForm.name || "Student Archer",
      phone: regForm.phone,
      email: regForm.email,
      isRegistered: true,
      joinedAt: Date.now()
    };
    
    setUserProfile(newProfile);
    try {
      localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
    } catch (e) {
      console.error("Failed to save profile:", e);
    }
  };

  const updateProfileStats = useCallback((newStats: TypingStats) => {
    setUserProfile(prev => {
      const totalTests = prev.stats.totalTests + 1;
      const totalTime = prev.stats.totalTime + newStats.time;
      const averageWpm = Math.round(((prev.stats.averageWpm * prev.stats.totalTests) + newStats.wpm) / totalTests);
      const averageAccuracy = Math.round(((prev.stats.averageAccuracy * prev.stats.totalTests) + newStats.accuracy) / totalTests);
      const bestWpm = Math.max(prev.stats.bestWpm, newStats.wpm);

      const updatedProfile = {
        ...prev,
        stats: {
          totalTests,
          totalTime,
          averageWpm,
          averageAccuracy,
          bestWpm
        }
      };

      try {
        localStorage.setItem('typemaster_profile', JSON.stringify(updatedProfile));
      } catch (e) {
        console.error("Failed to save profile:", e);
      }
      return updatedProfile;
    });
  }, []);

  const calculateStats = useCallback(() => {
    if (!startTimeRef.current) return;
    
    const endTime = Date.now();
    const durationInMinutes = Math.max((endTime - startTimeRef.current) / 60000, 0.001);
    
    let correctChars = 0;
    let totalChars = 0;
    let errors = 0;

    words.forEach((word, idx) => {
      if (idx < currentWordIndex) {
        totalChars += word.text.length + 1; // +1 for space
        if (word.status === 'correct') {
          correctChars += word.text.length + 1;
        } else {
          errors += 1;
        }
      }
    });

    const wpm = Math.round((correctChars / 5) / durationInMinutes);
    const rawWpm = Math.round((totalChars / 5) / durationInMinutes);
    const accuracy = totalChars > 0 ? Math.round((correctChars / totalChars) * 100) : 100;

    const newStats: TypingStats = {
      wpm,
      accuracy,
      rawWpm,
      characters: totalChars,
      errors,
      time: selectedTime === 0 ? Math.round((endTime - startTimeRef.current) / 1000) : selectedTime - timeLeft,
      timestamp: Date.now()
    };

    setStats(newStats);
    updateProfileStats(newStats);
    const updatedHistory = [newStats, ...history].slice(0, 10);
    setHistory(updatedHistory);
    try {
      localStorage.setItem('typemaster_history', JSON.stringify(updatedHistory));
    } catch (e) {
      console.error("Failed to save history:", e);
    }

    if (accuracy > 90 && wpm > 40) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#34d399', '#6ee7b7']
      });
    }
  }, [words, currentWordIndex, selectedTime, timeLeft, history, updateProfileStats]);

  const finishGame = useCallback(() => {
    setGameState('finished');
    if (timerRef.current) clearInterval(timerRef.current);
    calculateStats();
  }, [calculateStats]);

  useEffect(() => {
    if (gameState === 'playing' && timeLeft > 0 && selectedTime !== 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 0.1) {
            finishGame();
            return 0;
          }
          return Math.round((prev - 0.1) * 10) / 10;
        });
      }, 100);
    } else if (gameState === 'playing' && selectedTime === 0) {
      // Zen mode timer (counting up)
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => Math.round((prev + 0.1) * 10) / 10);
      }, 100);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState, timeLeft, finishGame]);

  const startGame = () => {
    setGameState('playing');
    startTimeRef.current = Date.now();
    focusInput();
  };

  const pauseGame = useCallback(() => {
    if (gameState !== 'playing') return;
    setGameState('paused');
    pauseStartTimeRef.current = Date.now();
    if (timerRef.current) clearInterval(timerRef.current);
  }, [gameState]);

  const resumeGame = useCallback(() => {
    if (gameState !== 'paused') return;
    setGameState('playing');
    if (pauseStartTimeRef.current && startTimeRef.current) {
      const pauseDuration = Date.now() - pauseStartTimeRef.current;
      startTimeRef.current += pauseDuration;
    }
    pauseStartTimeRef.current = null;
    focusInput();
  }, [gameState]);

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (gameState === 'idle') {
      startGame();
    }
    if (gameState !== 'playing') return;
    
    const value = e.target.value;
    const lastChar = value[value.length - 1] || "";
    setLastKeyPressed(lastChar);
    playKeySound();
    
    if (value.endsWith(' ')) {
      const typedWord = value.trim();
      const currentWord = words[currentWordIndex];
      const isCorrect = typedWord === currentWord.text;
      
      const newWords = [...words];
      newWords[currentWordIndex].status = isCorrect ? 'correct' : 'incorrect';
      setWords(newWords);

      if (!isCorrect && practiceMode === 'accuracy') {
        finishGame();
        return;
      }

      if (isCorrect) {
        setStreak(prev => {
          const next = prev + 1;
          if (next > maxStreak) setMaxStreak(next);
          return next;
        });
      } else {
        setStreak(0);
      }

      // Update live accuracy
      const correctCount = newWords.filter((w, i) => i <= currentWordIndex && w.status === 'correct').length;
      setLiveAccuracy(Math.round((correctCount / (currentWordIndex + 1)) * 100));
      
      if (currentWordIndex === words.length - 1) {
        finishGame();
      } else {
        setCurrentWordIndex(prev => prev + 1);
        setInputValue("");
      }
    } else {
      const currentWord = words[currentWordIndex];
      const isMistakeNow = value.length > inputValue.length && 
        value[value.length - 1] !== currentWord.text[value.length - 1];
      
      if (isMistakeNow) {
        setIsMistake(true);
        playErrorSound();
        setTimeout(() => setIsMistake(false), 200);
        
        if (practiceMode === 'accuracy') {
          finishGame();
          return;
        }
      }
      
      setInputValue(value);
    }
  };

  const focusInput = () => {
    inputRef.current?.focus();
  };

  const cycleMode = useCallback(() => {
    const modes = ['paragraph', 'quotes', 'words'];
    const nextIndex = (modes.indexOf(mode) + 1) % modes.length;
    const nextMode = modes[nextIndex];
    setMode(nextMode);
    initGame(topic, difficulty, nextMode);
  }, [mode, topic, difficulty, initGame]);

  const cyclePracticeMode = useCallback(() => {
    const modes: PracticeMode[] = ['timed', 'zen', 'accuracy'];
    const nextIndex = (modes.indexOf(practiceMode) + 1) % modes.length;
    const nextMode = modes[nextIndex];
    setPracticeMode(nextMode);
    if (nextMode === 'zen' || nextMode === 'accuracy') setSelectedTime(0);
    else setSelectedTime(30);
    initGame(topic, difficulty, mode);
  }, [practiceMode, topic, difficulty, mode, initGame]);

  const cycleDifficulty = useCallback(() => {
    const diffs = ['easy', 'medium', 'hard'];
    const nextIndex = (diffs.indexOf(difficulty) + 1) % diffs.length;
    const nextDiff = diffs[nextIndex];
    setDifficulty(nextDiff);
    initGame(topic, nextDiff, mode);
    
    const newProfile = {
      ...userProfile,
      settings: { ...userProfile.settings, difficulty: nextDiff }
    };
    setUserProfile(newProfile);
    localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
  }, [difficulty, topic, mode, userProfile, initGame]);

  const cycleTopic = useCallback(() => {
    const nextIndex = (TOPICS.findIndex(t => t.id === topic) + 1) % TOPICS.length;
    const nextTopic = TOPICS[nextIndex].id;
    setTopic(nextTopic);
    initGame(nextTopic, difficulty, mode);
  }, [topic, difficulty, mode, initGame]);

  return (
    <div className={cn(
      "min-h-screen flex flex-col items-center justify-center p-4 md:p-8 max-w-5xl mx-auto transition-all duration-300",
      userProfile.settings?.theme === 'light' ? "vibrant-bg text-zinc-900" : "dark:bg-[#111111] dark:text-[#eeeeee] bg-zinc-50 text-zinc-900",
      isMistake && "animate-shake"
    )} onClick={() => {
      if (gameState === 'paused') resumeGame();
      else focusInput();
    }}>
      <AnimatePresence mode="wait">
        {!userProfile.isRegistered ? (
          <motion.div
            key="registration"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center mb-8">
              <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-4">
                <Keyboard className="text-black w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold">Welcome to TypeMaster</h2>
              <p className="text-zinc-500 text-sm text-center mt-2">Register to track your progress and compete with others.</p>
            </div>

            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono uppercase text-zinc-500 mb-1 ml-1">Phone Number (Required)</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="tel"
                    placeholder="+1 234 567 890"
                    value={regForm.phone}
                    onChange={(e) => setRegForm({ ...regForm, phone: e.target.value })}
                    className="w-full bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-emerald-500 transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase text-zinc-500 mb-1 ml-1">Full Name (Optional)</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    placeholder="John Doe"
                    value={regForm.name}
                    onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
                    className="w-full bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase text-zinc-500 mb-1 ml-1">Email Address (Optional)</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    type="email"
                    placeholder="john@example.com"
                    value={regForm.email}
                    onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                    className="w-full bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>

              {regError && <p className="text-red-500 text-xs mt-2 text-center">{regError}</p>}

              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 mt-6 shadow-lg shadow-emerald-500/20"
              >
                Start Typing <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        ) : (
          <motion.div
            key="main-app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full h-full flex flex-col"
          >
            {/* Header */}
      <header className="w-full flex items-center justify-between mb-12">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Keyboard className="text-black w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">TypeMaster <span className="text-emerald-500">Pro</span></h1>
            <p className="text-xs text-zinc-500 font-mono uppercase tracking-widest">Student Edition</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-zinc-200 dark:bg-zinc-900/50 p-1 rounded-full border border-zinc-300 dark:border-zinc-800">
            <button onClick={toggleTheme} className="p-2 hover:bg-zinc-300 dark:hover:bg-zinc-800 rounded-full transition-colors text-zinc-500 dark:text-zinc-400">
              {userProfile.settings?.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
            <div className="relative">
              <button 
                onClick={() => setShowVolumeSettings(!showVolumeSettings)} 
                className={cn(
                  "p-2 rounded-full transition-colors",
                  showVolumeSettings ? "bg-emerald-500 text-black" : "hover:bg-zinc-300 dark:hover:bg-zinc-800 text-zinc-500 dark:text-zinc-400"
                )}
              >
                {userProfile.settings?.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
              
              <AnimatePresence>
                {showVolumeSettings && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setShowVolumeSettings(false)} 
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-2 w-64 bg-white dark:bg-[#111111] border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl p-4 z-50"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-xs font-bold uppercase tracking-widest text-zinc-500">Sound Settings</span>
                        <button 
                          onClick={toggleSound}
                          className={cn(
                            "text-[10px] px-2 py-1 rounded-md font-bold uppercase transition-all",
                            userProfile.settings?.soundEnabled ? "bg-emerald-500/10 text-emerald-500" : "bg-zinc-100 dark:bg-zinc-800 text-zinc-400"
                          )}
                        >
                          {userProfile.settings?.soundEnabled ? "Enabled" : "Muted"}
                        </button>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <label className="text-[10px] text-zinc-400 font-mono uppercase">Key Press</label>
                            <span className="text-[10px] text-emerald-500 font-mono">{Math.round((userProfile.settings?.keyVolume ?? 0.2) * 100)}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="1" 
                            step="0.01"
                            value={userProfile.settings?.keyVolume ?? 0.2}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              const newProfile = { 
                                ...userProfile, 
                                settings: { ...userProfile.settings, keyVolume: val } 
                              };
                              setUserProfile(newProfile);
                              localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                            }}
                            className="w-full h-1 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <label className="text-[10px] text-zinc-400 font-mono uppercase">Ambient</label>
                            <span className="text-[10px] text-emerald-500 font-mono">{Math.round((userProfile.settings?.ambientVolume ?? 0.15) * 100)}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="1" 
                            step="0.01"
                            value={userProfile.settings?.ambientVolume ?? 0.15}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              const newProfile = { 
                                ...userProfile, 
                                settings: { ...userProfile.settings, ambientVolume: val } 
                              };
                              setUserProfile(newProfile);
                              localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                            }}
                            className="w-full h-1 bg-zinc-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                          />
                        </div>
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>

          <button 
            onClick={(e) => { e.stopPropagation(); setShowProfile(true); }}
            className="flex items-center gap-3 bg-zinc-200 dark:bg-zinc-900/50 hover:bg-zinc-300 dark:hover:bg-zinc-800 p-1.5 pr-4 rounded-full border border-zinc-300 dark:border-zinc-800 transition-all group"
          >
            <img src={userProfile.avatar} alt="Avatar" className="w-8 h-8 rounded-full border border-zinc-400 dark:border-zinc-700 group-hover:border-emerald-500 transition-colors" />
            <div className="text-left hidden sm:block">
              <div className="text-[10px] text-zinc-500 font-mono uppercase leading-none mb-1">Profile</div>
              <div className="text-xs font-bold leading-none">{userProfile.username}</div>
            </div>
          </button>
        </div>
      </header>

      <main className="w-full flex-1 flex flex-col items-center justify-center relative">
        <AnimatePresence mode="wait">
          {gameState !== 'finished' ? (
            <motion.div 
              key="typing-area"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full"
            >
              {/* Topic Selector */}
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                {TOPICS.map(t => (
                  <button
                    key={t.id}
                    onClick={() => { setTopic(t.id); initGame(t.id, difficulty, mode); }}
                    className={cn(
                      "px-4 py-2 rounded-xl text-sm font-medium transition-all border flex items-center gap-2",
                      topic === t.id 
                        ? "bg-emerald-500/10 border-emerald-500 text-emerald-500" 
                        : "bg-zinc-900/50 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
                    )}
                  >
                    <span>{t.icon}</span>
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Difficulty & Mode Selector */}
              <div className="flex flex-wrap justify-center gap-4 mb-6">
                <div className="flex items-center gap-2 bg-zinc-200 dark:bg-zinc-900/50 p-1 rounded-xl border border-zinc-300 dark:border-zinc-800">
                  {[
                    { id: 'timed', label: 'Timed', icon: <Timer className="w-3 h-3" /> },
                    { id: 'zen', label: 'Zen', icon: <Wind className="w-3 h-3" /> },
                    { id: 'accuracy', label: 'Accuracy', icon: <Target className="w-3 h-3" /> }
                  ].map(m => (
                    <button
                      key={m.id}
                      onClick={() => { 
                        setPracticeMode(m.id as PracticeMode);
                        if (m.id === 'zen') setSelectedTime(0);
                        else if (m.id === 'accuracy') setSelectedTime(0);
                        else if (selectedTime === 0) setSelectedTime(30);
                        initGame(topic, difficulty, mode);
                      }}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-2",
                        practiceMode === m.id ? "bg-blue-500 text-white" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                      )}
                    >
                      {m.icon}
                      {m.label}
                    </button>
                  ))}
                </div>

                {practiceMode === 'timed' && (
                  <div className="flex items-center gap-2 bg-zinc-200 dark:bg-zinc-900/50 p-1 rounded-xl border border-zinc-300 dark:border-zinc-800">
                    {[15, 30, 60, 120, 300].map(time => (
                      <button
                        key={time}
                        onClick={() => { setSelectedTime(time); setTimeLeft(time); }}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                          selectedTime === time ? "bg-emerald-500 text-black" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                        )}
                      >
                        {time >= 60 ? `${time / 60}m` : `${time}s`}
                      </button>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2 bg-zinc-200 dark:bg-zinc-900/50 p-1 rounded-xl border border-zinc-300 dark:border-zinc-800">
                  {['easy', 'medium', 'hard'].map(d => (
                    <button
                      key={d}
                      onClick={() => { 
                        setDifficulty(d); 
                        initGame(topic, d, mode);
                        const newProfile = {
                          ...userProfile,
                          settings: { ...userProfile.settings, difficulty: d }
                        };
                        setUserProfile(newProfile);
                        localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                      }}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                        difficulty === d ? "bg-zinc-900 dark:bg-zinc-100 text-white dark:text-black" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                      )}
                    >
                      {d === 'easy' ? 'Beginner' : d === 'medium' ? 'Intermediate' : 'Advanced'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Stats */}
              <div className="flex justify-center items-center gap-12 mb-8">
                <div className="text-center">
                  <div className="flex items-center gap-2 text-zinc-500 mb-1 justify-center">
                    <Timer className="w-4 h-4" />
                    <span className="text-xs font-mono uppercase tracking-wider">{selectedTime === 0 ? "Elapsed" : "Time"}</span>
                  </div>
                  <div className="text-3xl font-mono font-bold text-emerald-500 tabular-nums">
                    {selectedTime === 0 ? (gameState === 'playing' || gameState === 'paused' ? timeLeft.toFixed(1) : "0.0") : timeLeft.toFixed(1)}<span className="text-xs ml-0.5 opacity-50 font-sans">s</span>
                  </div>
                </div>

                {/* Pause Button */}
                {(gameState === 'playing' || gameState === 'paused') && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      if (gameState === 'playing') pauseGame();
                      else resumeGame();
                    }}
                    className="w-12 h-12 flex items-center justify-center rounded-2xl bg-zinc-200 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-700 transition-all text-zinc-600 dark:text-zinc-300 shadow-sm"
                  >
                    {gameState === 'playing' ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>
                )}

                <div className="text-center">
                  <div className="flex items-center gap-2 text-zinc-500 mb-1 justify-center">
                    <Zap className="w-4 h-4" />
                    <span className="text-xs font-mono uppercase tracking-wider">WPM</span>
                  </div>
                  <div className="text-3xl font-mono font-bold tabular-nums">
                    {gameState === 'playing' ? Math.round(((currentWordIndex) / ((Date.now() - (startTimeRef.current || Date.now())) / 60000)) || 0) : 0}<span className="text-xs ml-0.5 opacity-50 font-sans">wpm</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="flex items-center gap-2 text-zinc-500 mb-1 justify-center">
                    <Target className="w-4 h-4" />
                    <span className="text-xs font-mono uppercase tracking-wider">ACC</span>
                  </div>
                  <div className="text-3xl font-mono font-bold text-zinc-100 tabular-nums">
                    {liveAccuracy}<span className="text-xs ml-0.5 opacity-50 font-sans">%</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="flex items-center gap-2 text-zinc-500 mb-1 justify-center">
                    <Trophy className="w-4 h-4" />
                    <span className="text-xs font-mono uppercase tracking-wider">Streak</span>
                  </div>
                  <div className="text-3xl font-mono font-bold text-amber-500">{streak}</div>
                </div>
              </div>

              {/* Typing Container */}
              <div className="relative group">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={handleInput}
                  className="absolute opacity-0 cursor-default"
                  autoFocus
                />
                
                <div className="text-xl md:text-2xl leading-relaxed font-mono text-zinc-600 select-none min-h-[100px]">
                  <div className="flex flex-wrap gap-x-2 gap-y-1">
                    {words.map((word, idx) => {
                      const isActive = idx === currentWordIndex;
                      const isPast = idx < currentWordIndex;
                      
                      return (
                        <span 
                          key={idx} 
                          className={cn(
                            "relative transition-all duration-200",
                            word.status === 'correct' && "text-emerald-500",
                            word.status === 'incorrect' && "text-red-500 underline decoration-red-500/50 underline-offset-4",
                            idx > currentWordIndex && "text-zinc-600"
                          )}
                        >
                          {isActive ? (
                            <span className="relative inline-flex">
                              {/* Accurate Caret */}
                              <motion.div 
                                layoutId="caret"
                                className="absolute w-0.5 h-[1.2em] bg-blue-500 z-10"
                                style={{ 
                                  left: `${Math.min(inputValue.length, word.text.length) * 0.6}em`,
                                  top: '0.1em'
                                }}
                                transition={{ type: "spring", stiffness: 400, damping: 35 }}
                              />
                              
                              {word.text.split('').map((char, charIdx) => {
                                let charStatus = 'pending';
                                const isCurrentChar = charIdx === inputValue.length;
                                if (charIdx < inputValue.length) {
                                  charStatus = char === inputValue[charIdx] ? 'correct' : 'incorrect';
                                }
                                return (
                                  <span 
                                    key={charIdx} 
                                    className={cn(
                                      charStatus === 'correct' && "char-correct",
                                      charStatus === 'incorrect' && "char-incorrect",
                                      charStatus === 'pending' && (userProfile.settings?.theme === 'light' ? "text-zinc-400" : "text-zinc-100"),
                                      isCurrentChar && "char-current"
                                    )}
                                  >
                                    {charStatus === 'incorrect' ? inputValue[charIdx] : char}
                                  </span>
                                );
                              })}
                              
                              {/* Extra characters typed beyond word length */}
                              {inputValue.length > word.text.length && (
                                <span className="flex">
                                  {inputValue.slice(word.text.length).split('').map((extraChar, extraIdx) => (
                                    <span key={extraIdx} className="char-incorrect opacity-70">
                                      {extraChar}
                                    </span>
                                  ))}
                                </span>
                              )}
                            </span>
                          ) : (
                            word.text
                          )}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {isLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-[#111111]/80 backdrop-blur-sm z-30">
                    <div className="flex flex-col items-center gap-4">
                      <RefreshCcw className="w-8 h-8 text-emerald-500 animate-spin" />
                      <p className="text-sm font-mono text-zinc-400">Generating AI challenge...</p>
                    </div>
                  </div>
                )}

                {gameState === 'idle' && !isLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-[#111111]/40 backdrop-blur-[2px] z-20 rounded-3xl transition-all group-hover:bg-[#111111]/20">
                    <div className="flex items-center gap-4">
                      <motion.button
                        onClick={focusInput}
                        animate={{
                          scale: [1, 1.05, 1],
                          boxShadow: [
                            "0 0 0 0px rgba(16, 185, 129, 0)",
                            "0 0 0 20px rgba(16, 185, 129, 0.1)",
                            "0 0 0 0px rgba(16, 185, 129, 0)"
                          ]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                        className="px-10 py-4 bg-emerald-500 text-black font-bold rounded-2xl flex items-center gap-3 shadow-xl shadow-emerald-500/20 hover:bg-emerald-400 transition-colors"
                      >
                        <Zap className="w-5 h-5" />
                        <div className="flex flex-col items-start">
                          <span className="uppercase tracking-wider text-sm">Start Typing</span>
                          <span className="text-[10px] opacity-60 font-normal normal-case">or press any key</span>
                        </div>
                      </motion.button>
                      
                      <button 
                        onClick={() => initGame()}
                        className="w-14 h-14 bg-zinc-800 text-zinc-400 rounded-2xl flex items-center justify-center hover:bg-zinc-700 hover:text-white transition-all border border-zinc-700"
                        title="Refresh Challenge"
                      >
                        <RefreshCcw className="w-6 h-6" />
                      </button>
                    </div>
                  </div>
                )}
                {gameState === 'paused' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-[#111111]/60 backdrop-blur-md z-20 rounded-3xl transition-all">
                    <div className="flex flex-col items-center gap-6">
                      <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center shadow-2xl shadow-blue-500/20 animate-pulse">
                        <Pause className="w-10 h-10 text-white" />
                      </div>
                      <div className="text-center">
                        <h2 className="text-2xl font-bold text-white mb-2">Session Paused</h2>
                        <p className="text-zinc-400 text-sm font-mono uppercase tracking-widest">Press ESC or click to resume</p>
                      </div>
                      <motion.button
                        onClick={resumeGame}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-10 py-4 bg-white text-black font-bold rounded-2xl flex items-center gap-3 shadow-xl hover:bg-zinc-100 transition-colors"
                      >
                        <Play className="w-5 h-5" />
                        <span className="uppercase tracking-wider text-sm">Resume Session</span>
                      </motion.button>
                    </div>
                  </div>
                )}
              </div>

                <div className="mt-8 w-full max-w-md">
                  <div className="h-2 w-full bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden border border-zinc-300 dark:border-zinc-700">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-green-500 to-blue-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${(currentWordIndex / words.length) * 100}%` }}
                      transition={{ type: "spring", stiffness: 100, damping: 20 }}
                    />
                  </div>
                </div>

                <div className="mt-8 flex flex-col items-center gap-8">
                  <VirtualKeyboard activeKey={lastKeyPressed} />
                  
                  <div className="flex items-center gap-4 text-zinc-500 text-sm bg-zinc-200/50 dark:bg-zinc-900/30 px-6 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-800/50">
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-zinc-300 dark:bg-zinc-800 rounded text-xs border border-zinc-400 dark:border-zinc-700">Tab</kbd>
                      <span>to restart</span>
                    </div>
                    <div className="w-px h-4 bg-zinc-300 dark:bg-zinc-800" />
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-zinc-300 dark:bg-zinc-800 rounded text-xs border border-zinc-400 dark:border-zinc-700">Space</kbd>
                      <span>for next word</span>
                    </div>
                  </div>
                </div>
            </motion.div>
          ) : (
            <motion.div 
              key="results"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-2xl"
            >
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-8 md:p-12 shadow-2xl">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <Trophy className="w-8 h-8 text-yellow-500" />
                    <h2 className="text-2xl font-bold">Session Complete!</h2>
                  </div>
                  {stats && (
                    <div className="flex flex-col items-end gap-1">
                      <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-1">
                        Mode: {practiceMode}
                      </div>
                      <div className={cn("px-4 py-1 rounded-full border text-sm font-bold uppercase tracking-tighter", getRank(stats.wpm).color, `border-current`)}>
                        Rank: {getRank(stats.wpm).name}
                      </div>
                      <div className="text-[10px] font-mono text-zinc-500">
                        {stats.wpm > userProfile.stats.averageWpm ? (
                          <span className="text-emerald-500">↑ {stats.wpm - userProfile.stats.averageWpm} above avg</span>
                        ) : (
                          <span className="text-zinc-500">↓ {userProfile.stats.averageWpm - stats.wpm} below avg</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">WPM</div>
                    <div className="text-2xl font-bold text-emerald-500">{stats?.wpm}</div>
                  </div>
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Accuracy</div>
                    <div className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">{stats?.accuracy}%</div>
                  </div>
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Words</div>
                    <div className="text-2xl font-bold text-zinc-600 dark:text-zinc-400">{currentWordIndex}</div>
                  </div>
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Errors</div>
                    <div className="text-2xl font-bold text-red-500">{stats?.errors}</div>
                  </div>
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Streak</div>
                    <div className="text-2xl font-bold text-amber-500">{maxStreak}</div>
                  </div>
                  <div className="bg-zinc-200 dark:bg-zinc-800/50 p-4 rounded-2xl border border-zinc-300 dark:border-zinc-700/50">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Time</div>
                    <div className="text-2xl font-bold text-blue-500">{stats?.time}s</div>
                  </div>
                </div>

                <div className="flex flex-col md:flex-row gap-4">
                  <motion.button 
                    onClick={() => initGame()}
                    animate={{
                      scale: [1, 1.02, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
                  >
                    <RefreshCcw className="w-5 h-5" />
                    Try Again
                  </motion.button>
                  <button 
                    onClick={() => {
                      const topics = ["space", "history", "coding", "nature", "science"];
                      const nextTopic = topics[Math.floor(Math.random() * topics.length)];
                      setTopic(nextTopic);
                      initGame(nextTopic);
                    }}
                    className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 border border-zinc-700"
                  >
                    <Zap className="w-5 h-5 text-emerald-500" />
                    New AI Challenge
                  </button>
                </div>
              </div>

              {/* History */}
              {history.length > 0 && (
                <div className="mt-12">
                  <div className="flex items-center gap-2 mb-4 text-zinc-400">
                    <BarChart3 className="w-4 h-4" />
                    <h3 className="text-sm font-mono uppercase tracking-wider">Recent Performance</h3>
                  </div>
                  <div className="space-y-2">
                    {history.map((item, i) => (
                      <div key={i} className="flex items-center justify-between bg-zinc-900/30 p-4 rounded-xl border border-zinc-800/50 text-sm">
                        <div className="flex items-center gap-6">
                          <span className="text-zinc-500 font-mono">{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          <span className="font-bold text-emerald-500">{item.wpm} WPM</span>
                          <span className="text-zinc-400">{item.accuracy}% ACC</span>
                        </div>
                        <div className="text-zinc-600 text-xs font-mono">
                          {item.time}s session
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Info */}
      <footer className="w-full mt-12 pt-8 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 text-zinc-500 text-xs font-mono">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>AI Powered Challenges</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-zinc-700" />
            <span>Real-time Analytics</span>
          </div>
          <div className="hidden lg:flex items-center gap-1.5 ml-4 px-3 py-1 bg-zinc-900/50 rounded-full border border-zinc-800">
            <span className="text-[10px] text-zinc-600">Shortcuts:</span>
            <span className="text-[10px] text-zinc-400">Alt + M/D/T</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 ml-4">
            <span className="text-zinc-600">Made with ❤️ by</span>
            <span className="text-zinc-400 font-bold">TypeMaster Team</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="hover:text-zinc-300 transition-colors flex items-center gap-1">
            <Settings className="w-3 h-3" /> Settings
          </button>
          <button 
            onClick={() => setShowTips(true)}
            className="hover:text-zinc-300 transition-colors flex items-center gap-1"
          >
            <Info className="w-3 h-3" /> About
          </button>
        </div>
      </footer>

      {/* Global Keyboard Listener for Shortcuts */}
      <GlobalKeyListener 
        onRestart={() => initGame()} 
        onCycleMode={cycleMode}
        onCyclePracticeMode={cyclePracticeMode}
        onCycleDifficulty={cycleDifficulty}
        onCycleTopic={cycleTopic}
        onTogglePause={() => {
          if (gameState === 'playing') pauseGame();
          else if (gameState === 'paused') resumeGame();
        }}
      />

      {/* Tips Modal */}
      <AnimatePresence>
        {showTips && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowTips(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-xl bg-[#111111] border border-zinc-800 rounded-3xl p-8 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <Info className="w-6 h-6 text-emerald-500" />
                <h2 className="text-2xl font-bold">About TypeMaster Pro</h2>
              </div>
              
              <div className="space-y-6 text-zinc-400 text-sm leading-relaxed">
                <section>
                  <h3 className="text-zinc-100 font-bold mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-500" /> The Project
                  </h3>
                  <p>TypeMaster Pro is an advanced typing practice platform designed for students and professionals. It leverages Gemini AI to generate dynamic, context-aware typing challenges across various topics, ensuring that your practice is always fresh and engaging.</p>
                </section>

                <section>
                  <h3 className="text-zinc-100 font-bold mb-2 flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-500" /> The Creator
                  </h3>
                  <p>Crafted with passion by a team of developers dedicated to building high-performance educational tools. Our mission is to make skill-building intuitive, beautiful, and effective.</p>
                </section>

                <section>
                  <h3 className="text-zinc-100 font-bold mb-2 flex items-center gap-2">
                    <Target className="w-4 h-4 text-emerald-500" /> Accuracy First
                  </h3>
                  <p>Speed comes naturally with time. Focus on hitting the right keys first. If you maintain 95%+ accuracy, your speed will increase without you even noticing.</p>
                </section>

                <section>
                  <h3 className="text-zinc-100 font-bold mb-2 flex items-center gap-2">
                    <Keyboard className="w-4 h-4 text-emerald-500" /> Home Row Position
                  </h3>
                  <p>Keep your fingers on the home row (ASDF JKL;). Use the small bumps on the 'F' and 'J' keys to orient yourself without looking down.</p>
                </section>

                <section>
                  <h3 className="text-zinc-100 font-bold mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-500" /> AI Challenges
                  </h3>
                  <p>Use the different topics and difficulties to challenge yourself. 'Hard' mode includes more complex punctuation and longer words, which is great for industry-level practice.</p>
                </section>

                <section className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                  <h3 className="text-zinc-100 font-bold mb-3 text-xs uppercase tracking-widest">Keyboard Shortcuts</h3>
                  <div className="grid grid-cols-2 gap-3 text-[11px]">
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Restart Test</span>
                      <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Tab</kbd>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Cycle Mode</span>
                      <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Alt + M</kbd>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Cycle Difficulty</span>
                      <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Alt + D</kbd>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Cycle Topic</span>
                      <kbd className="px-1.5 py-0.5 bg-zinc-800 rounded border border-zinc-700 text-zinc-300">Alt + T</kbd>
                    </div>
                  </div>
                </section>

                <div className="pt-4 border-t border-zinc-800 flex justify-between items-center">
                  <div className="flex flex-col">
                    <p className="text-[10px] font-mono uppercase tracking-widest text-zinc-500">TypeMaster Pro v1.2</p>
                    <p className="text-[9px] font-mono text-zinc-600">Built with React, Tailwind & Gemini AI</p>
                  </div>
                  <button 
                    onClick={() => setShowTips(false)}
                    className="px-6 py-2 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all"
                  >
                    Got it!
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Profile Modal */}
      <AnimatePresence>
        {showProfile && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowProfile(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl bg-[#111111] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl"
            >
              <div className="relative h-32 bg-gradient-to-r from-emerald-500/20 to-blue-500/20 border-b border-zinc-800">
                <div className="absolute -bottom-12 left-8 p-1 bg-[#111111] rounded-full border border-zinc-800">
                  <img src={userProfile.avatar} alt="Avatar" className="w-24 h-24 rounded-full" />
                </div>
              </div>
              
              <div className="pt-16 p-8">
                <div className="flex items-start justify-between mb-8">
                  <div className="flex-1 mr-4">
                    <input 
                      type="text" 
                      value={userProfile.username}
                      onChange={(e) => {
                        const newProfile = { ...userProfile, username: e.target.value };
                        setUserProfile(newProfile);
                        try {
                          localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                        } catch (err) {
                          console.error("Failed to save profile:", err);
                        }
                      }}
                      className="text-3xl font-bold mb-1 bg-transparent border-b border-transparent hover:border-zinc-700 focus:border-emerald-500 focus:outline-none w-full transition-all"
                    />
                    <p className="text-zinc-500 text-sm font-mono">Member since {new Date(userProfile.joinedAt).toLocaleDateString()}</p>
                    <div className="flex flex-wrap gap-4 mt-3">
                      {userProfile.phone && (
                        <div className="flex items-center gap-2 text-xs text-zinc-400 bg-zinc-900/50 px-3 py-1 rounded-full border border-zinc-800">
                          <Phone className="w-3 h-3" /> {userProfile.phone}
                        </div>
                      )}
                      {userProfile.email && (
                        <div className="flex items-center gap-2 text-xs text-zinc-400 bg-zinc-900/50 px-3 py-1 rounded-full border border-zinc-800">
                          <Mail className="w-3 h-3" /> {userProfile.email}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className={cn("px-4 py-2 rounded-xl border font-bold uppercase tracking-widest text-sm", getRank(userProfile.stats.bestWpm).color, "border-current bg-current/5")}>
                    {getRank(userProfile.stats.bestWpm).name}
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Best WPM</div>
                    <div className="text-2xl font-bold text-emerald-500">{userProfile.stats.bestWpm}</div>
                  </div>
                  <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Avg WPM</div>
                    <div className="text-2xl font-bold text-zinc-100">{userProfile.stats.averageWpm}</div>
                  </div>
                  <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Avg Accuracy</div>
                    <div className="text-2xl font-bold text-zinc-100">{userProfile.stats.averageAccuracy}%</div>
                  </div>
                  <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                    <div className="text-zinc-500 text-[10px] font-mono uppercase mb-1">Total Tests</div>
                    <div className="text-2xl font-bold text-zinc-100">{userProfile.stats.totalTests}</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-mono uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" /> Lifetime Activity
                  </h3>
                  <div className="bg-zinc-900/30 p-6 rounded-2xl border border-zinc-800/50">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-zinc-400 text-sm">Total Typing Time</span>
                      <span className="text-zinc-100 font-mono font-bold">{Math.round(userProfile.stats.totalTime / 60)} minutes</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(100, (userProfile.stats.totalTests / 100) * 100)}%` }}
                        className="h-full bg-emerald-500"
                      />
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2 font-mono">Progress to Level 10: {userProfile.stats.totalTests}/100 tests</p>
                  </div>
                </div>

                <div className="mt-8 space-y-4">
                  <h3 className="text-sm font-mono uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                    <Volume2 className="w-4 h-4" /> Sound Settings
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-zinc-900/30 p-6 rounded-2xl border border-zinc-800/50">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-xs text-zinc-400 font-mono uppercase">Key Press Volume</label>
                        <span className="text-[10px] text-emerald-500 font-mono">{Math.round((userProfile.settings?.keyVolume ?? 0.2) * 100)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.01"
                        value={userProfile.settings?.keyVolume ?? 0.2}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          const newProfile = { 
                            ...userProfile, 
                            settings: { ...userProfile.settings, keyVolume: val } 
                          };
                          setUserProfile(newProfile);
                          try {
                            localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                          } catch (err) {
                            console.error("Failed to save profile:", err);
                          }
                        }}
                        className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                      />
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-xs text-zinc-400 font-mono uppercase">Ambient Volume (Zen)</label>
                        <span className="text-[10px] text-emerald-500 font-mono">{Math.round((userProfile.settings?.ambientVolume ?? 0.15) * 100)}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.01"
                        value={userProfile.settings?.ambientVolume ?? 0.15}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          const newProfile = { 
                            ...userProfile, 
                            settings: { ...userProfile.settings, ambientVolume: val } 
                          };
                          setUserProfile(newProfile);
                          try {
                            localStorage.setItem('typemaster_profile', JSON.stringify(newProfile));
                          } catch (err) {
                            console.error("Failed to save profile:", err);
                          }
                        }}
                        className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex justify-end">
                  <button 
                    onClick={() => setShowProfile(false)}
                    className="px-8 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl transition-all"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )}
</AnimatePresence>
    </div>
  );
}

function GlobalKeyListener({ 
  onRestart, 
  onCycleMode, 
  onCyclePracticeMode,
  onCycleDifficulty, 
  onCycleTopic,
  onTogglePause
}: { 
  onRestart: () => void;
  onCycleMode: () => void;
  onCyclePracticeMode: () => void;
  onCycleDifficulty: () => void;
  onCycleTopic: () => void;
  onTogglePause: () => void;
}) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Tab for Restart
      if (e.key === 'Tab') {
        e.preventDefault();
        onRestart();
      }

      // Escape for Pause
      if (e.key === 'Escape') {
        e.preventDefault();
        onTogglePause();
      }
      
      // Alt + M for Cycle Mode
      if (e.altKey && e.key.toLowerCase() === 'm') {
        e.preventDefault();
        onCycleMode();
      }

      // Alt + P for Cycle Practice Mode
      if (e.altKey && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        onCyclePracticeMode();
      }
      
      // Alt + D for Cycle Difficulty
      if (e.altKey && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        onCycleDifficulty();
      }
      
      // Alt + T for Cycle Topic
      if (e.altKey && e.key.toLowerCase() === 't') {
        e.preventDefault();
        onCycleTopic();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onRestart, onCycleMode, onCyclePracticeMode, onCycleDifficulty, onCycleTopic]);
  return null;
}
