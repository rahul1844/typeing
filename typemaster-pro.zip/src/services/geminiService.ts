import { GoogleGenAI } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export async function generateTypingText(topic: string = "general", difficulty: string = "medium", mode: string = "paragraph") {
  try {
    const ai = getAI();
    let prompt = "";
    
    if (mode === "quotes") {
      prompt = `Generate 3 famous inspirational quotes about ${topic}. Return them as a single continuous string without numbers or authors.`;
    } else if (mode === "words") {
      prompt = `Generate a list of 30 random common words related to ${topic}. Separate them with spaces.`;
    } else {
      const difficultyPrompt = difficulty === "easy" 
        ? "Use very simple, short words and basic punctuation." 
        : difficulty === "hard" 
        ? "Use complex vocabulary, scientific terms, and varied punctuation (semicolons, dashes)." 
        : "Use standard vocabulary and common punctuation.";
        
      prompt = `Generate an engaging ${mode} (about 30-45 words) for a typing practice test. Topic: ${topic}. ${difficultyPrompt} Do not include any special formatting, titles, or markdown. Just the plain text.`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text?.trim().replace(/\n/g, ' ') || "The quick brown fox jumps over the lazy dog. Typing is a fundamental skill in the digital age. Practice makes perfect, and consistency is key to improving your speed and accuracy over time.";
  } catch (error) {
    console.error("Error generating text:", error);
    return "The quick brown fox jumps over the lazy dog. Typing is a fundamental skill in the digital age. Practice makes perfect, and consistency is key to improving your speed and accuracy over time.";
  }
}
