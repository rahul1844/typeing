import React from 'react';
import { cn } from '../lib/utils';

const ROWS = [
  ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
  ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
  ['z', 'x', 'c', 'v', 'b', 'n', 'm']
];

const FINGER_MAP: Record<string, string> = {
  'q': 'lp', 'a': 'lp', 'z': 'lp',
  'w': 'lr', 's': 'lr', 'x': 'lr',
  'e': 'lm', 'd': 'lm', 'c': 'lm',
  'r': 'li', 't': 'li', 'f': 'li', 'g': 'li', 'v': 'li', 'b': 'li',
  'y': 'ri', 'u': 'ri', 'h': 'ri', 'j': 'ri', 'n': 'ri', 'm': 'ri',
  'i': 'rm', 'k': 'rm',
  'o': 'rr', 'l': 'rr',
  'p': 'rp',
  ' ': 'thumb'
};

const FINGER_COLORS: Record<string, { border: string, bg: string, dot: string, side: string, name: string }> = {
  'lp': { border: 'border-rose-500/30', bg: 'bg-rose-500/5', dot: 'bg-rose-500', side: 'L', name: 'Pinky' },
  'lr': { border: 'border-orange-500/30', bg: 'bg-orange-500/5', dot: 'bg-orange-500', side: 'L', name: 'Ring' },
  'lm': { border: 'border-amber-500/30', bg: 'bg-amber-500/5', dot: 'bg-amber-500', side: 'L', name: 'Middle' },
  'li': { border: 'border-emerald-500/30', bg: 'bg-emerald-500/5', dot: 'bg-emerald-500', side: 'L', name: 'Index' },
  'ri': { border: 'border-emerald-500/30', bg: 'bg-emerald-500/5', dot: 'bg-emerald-500', side: 'R', name: 'Index' },
  'rm': { border: 'border-amber-500/30', bg: 'bg-amber-500/5', dot: 'bg-amber-500', side: 'R', name: 'Middle' },
  'rr': { border: 'border-orange-500/30', bg: 'bg-orange-500/5', dot: 'bg-orange-500', side: 'R', name: 'Ring' },
  'rp': { border: 'border-rose-500/30', bg: 'bg-rose-500/5', dot: 'bg-rose-500', side: 'R', name: 'Pinky' },
  'thumb': { border: 'border-blue-500/30', bg: 'bg-blue-500/5', dot: 'bg-blue-500', side: 'L/R', name: 'Thumb' }
};

const SHORTCUTS: Record<string, string> = {
  'm': 'Mode',
  'd': 'Diff',
  't': 'Topic',
  'p': 'Prac'
};

interface VirtualKeyboardProps {
  activeKey: string;
}

export const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({ activeKey }) => {
  return (
    <div className="w-full max-w-2xl mx-auto p-6 bg-zinc-100 dark:bg-zinc-900/50 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-inner">
      <div className="flex flex-col gap-2">
        {ROWS.map((row, i) => (
          <div key={i} className="flex justify-center gap-1.5">
            {row.map(key => {
              const finger = FINGER_MAP[key];
              const colors = FINGER_COLORS[finger];
              const shortcut = SHORTCUTS[key];
              
              return (
                <div
                  key={key}
                  className={cn(
                    "w-9 h-9 md:w-11 md:h-11 flex flex-col items-center justify-center rounded-xl text-sm font-bold uppercase transition-all duration-75 border shadow-sm relative overflow-hidden",
                    activeKey.toLowerCase() === key
                      ? "bg-emerald-500 border-emerald-600 text-white scale-95 shadow-inner"
                      : cn("bg-white dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400", colors.border, colors.bg)
                  )}
                >
                  <span className="z-10">{key}</span>
                  
                  {/* Finger Dot Indicator */}
                  {activeKey.toLowerCase() !== key && (
                    <div className={cn("absolute bottom-1 w-1.5 h-1.5 rounded-full shadow-sm", colors.dot)} />
                  )}

                  {/* Finger Label (Side + Initial) */}
                  {activeKey.toLowerCase() !== key && (
                    <span className="absolute top-0.5 left-1 text-[6px] opacity-40 font-mono font-bold">
                      {colors.side}{colors.name[0]}
                    </span>
                  )}

                  {shortcut && (
                    <span className={cn(
                      "absolute -top-1 -right-1 text-[8px] px-1 rounded-md font-mono z-20",
                      activeKey.toLowerCase() === key ? "bg-white text-emerald-600" : "bg-zinc-200 dark:bg-zinc-700 text-zinc-500"
                    )}>
                      Alt
                    </span>
                  )}
                  {shortcut && (
                    <span className="text-[7px] opacity-60 font-mono mt-0.5 z-10">{shortcut}</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
        <div className="flex justify-center mt-1">
          <div 
            className={cn(
              "h-9 md:h-11 w-40 md:w-56 rounded-xl border transition-all duration-75 shadow-sm flex items-center justify-center relative",
              activeKey === ' '
                ? "bg-emerald-500 border-emerald-600 scale-95 shadow-inner"
                : cn("bg-white dark:bg-zinc-800", FINGER_COLORS['thumb'].border, FINGER_COLORS['thumb'].bg)
            )}
          >
            <span className="text-[8px] text-zinc-400 uppercase font-mono">Space / Thumb</span>
            {activeKey !== ' ' && (
              <div className={cn("absolute bottom-1.5 w-1 h-1 rounded-full", FINGER_COLORS['thumb'].dot)} />
            )}
          </div>
        </div>
      </div>
      
      {/* Hand Visualization Guide */}
      <div className="mt-4 flex justify-center gap-16">
        <div className="flex flex-col items-center gap-1">
          <div className="flex gap-1.5 items-end h-6">
            {['lp', 'lr', 'lm', 'li'].map(f => (
              <div key={f} className={cn("w-2.5 rounded-t-full", FINGER_COLORS[f].dot, f === 'lp' ? 'h-3' : f === 'lm' ? 'h-6' : 'h-5')} />
            ))}
            <div className={cn("w-2.5 h-3 rounded-full ml-2", FINGER_COLORS['thumb'].dot)} />
          </div>
          <span className="text-[8px] text-zinc-500 font-mono uppercase">Left Hand</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <div className="flex gap-1.5 items-end h-6">
            <div className={cn("w-2.5 h-3 rounded-full mr-2", FINGER_COLORS['thumb'].dot)} />
            {['ri', 'rm', 'rr', 'rp'].map(f => (
              <div key={f} className={cn("w-2.5 rounded-t-full", FINGER_COLORS[f].dot, f === 'rp' ? 'h-3' : f === 'rm' ? 'h-6' : 'h-5')} />
            ))}
          </div>
          <span className="text-[8px] text-zinc-500 font-mono uppercase">Right Hand</span>
        </div>
      </div>

      {/* Finger Legend */}
      <div className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2 border-t border-zinc-200 dark:border-zinc-800 pt-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-rose-500" />
          <span className="text-[10px] text-zinc-500 uppercase font-mono"><span className="text-zinc-400">L/R</span> Pinky</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-orange-500" />
          <span className="text-[10px] text-zinc-500 uppercase font-mono"><span className="text-zinc-400">L/R</span> Ring</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-amber-500" />
          <span className="text-[10px] text-zinc-500 uppercase font-mono"><span className="text-zinc-400">L/R</span> Middle</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-[10px] text-zinc-500 uppercase font-mono"><span className="text-zinc-400">L/R</span> Index</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-blue-500" />
          <span className="text-[10px] text-zinc-500 uppercase font-mono">Thumb</span>
        </div>
      </div>
    </div>
  );
};
