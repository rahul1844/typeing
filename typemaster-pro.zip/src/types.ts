export interface TypingStats {
  wpm: number;
  accuracy: number;
  rawWpm: number;
  characters: number;
  errors: number;
  time: number;
  timestamp: number;
}

export interface UserStats {
  totalTests: number;
  averageWpm: number;
  bestWpm: number;
  totalTime: number;
  averageAccuracy: number;
}

export interface UserSettings {
  theme: 'light' | 'dark';
  soundEnabled: boolean;
  keyVolume: number;
  ambientVolume: number;
  difficulty: string;
}

export interface UserProfile {
  username: string;
  phone?: string;
  email?: string;
  avatar: string;
  joinedAt: number;
  stats: UserStats;
  settings: UserSettings;
  isRegistered: boolean;
}

export type GameState = 'idle' | 'playing' | 'paused' | 'finished';
export type PracticeMode = 'timed' | 'zen' | 'accuracy';

export interface Word {
  text: string;
  status: 'pending' | 'correct' | 'incorrect' | 'active';
}
